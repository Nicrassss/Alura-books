# TurmaJResponsividade
Repositório criado para hospedar projeto construido na turma J GE de trilhas de programação
